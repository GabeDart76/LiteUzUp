﻿using LiteUzUpWebsite.Data;
using LiteUzUpWebsite.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace LiteUzUpWebsite.Areas.Admin.Controllers
{

    [Area("Admin")]
    public class ProductController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _he;

        public ProductController(ApplicationDbContext context, IWebHostEnvironment he)
        {
            _context = context;
            _he = he;
        }

        public IActionResult Index()
        {
            return View(_context.Products.Include(c => c.ProductTypes).ToList());
        }

        [HttpPost]
        public IActionResult Index(decimal? lowamount, decimal? largeamount)
        {
            var products = _context.Products.Include(c => c.ProductTypes).Where(c => c.Price >= lowamount && c.Price <= largeamount).ToList();
            if (lowamount == null || largeamount == null)
            {
                products = _context.Products.Include(c => c.ProductTypes).ToList();
            }
            return View(products);
        }

        public ActionResult Create()
        {
            ViewData["ProductTypeId"] = new SelectList(_context.ProductTypes.ToList(), "Id", "ProductType");
            return View();
        }

        [HttpPost]
        public async Task<IActionResult>Create(Products products, IFormFile image)
        {
            if (ModelState.IsValid)
            {
                var SearchProduct = _context.Products.FirstOrDefault(c => c.Name == products.Name && c.Colour == products.Colour);
                if(SearchProduct != null)
                {
                    ViewBag.message = "This product already exists";
                    ViewData["ProductTypeId"] = new SelectList(_context.ProductTypes.ToList(), "Id", "ProductType");
                    return View(products);
                }
                if (image != null)
                {
                    var name = Path.Combine(_he.WebRootPath + "\\image", Path.GetFileName(image.FileName));
                    await image.CopyToAsync(new FileStream(name, FileMode.Create));
                    products.Image = "imag\\" + image.FileName;
                }
                if (image == null)
                {
                    products.Image = "image\\noimage.png";
                }

                _context.Products.Add(products);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(products);
        }

        public ActionResult Edit(int? id)
        {
            ViewData["ProductTypeId"] = new SelectList(_context.ProductTypes.ToList(), "Id", "ProductType");
            if(id == null)
            {
                return NotFound();
            }
            var product = _context.Products.Include(c => c.ProductTypes).FirstOrDefault(c => c.Id == id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        [HttpPost]
        [ActionName("Edit")]
        public async Task <IActionResult> Edit(Products products, IFormFile image)
        {
            if (ModelState.IsValid)
            {
                var SearchProduct = _context.Products.FirstOrDefault(c => c.Name == products.Name && c.Colour == products.Colour);
                if (SearchProduct != null)
                {
                    ViewBag.message = "This product already exists";
                    ViewData["ProductTypeId"] = new SelectList(_context.ProductTypes.ToList(), "Id", "ProductType");
                    return View(products);
                }
                if (image != null)
                {
                    var name = Path.Combine(_he.WebRootPath + "\\image", Path.GetFileName(image.FileName));
                    await image.CopyToAsync(new FileStream(name, FileMode.Create));
                    products.Image = "image\\" + image.FileName;
                }
                if (image == null)
                {
                    products.Image = "image\\noimage.png";
                }

                _context.Products.Update(products);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(products);
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var product = _context.Products.Include(c => c.ProductTypes).FirstOrDefault(c => c.Id == id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        public ActionResult Delete(int? id)
        {
            if(id == null)
            {
                return NotFound();
            }
            
            var product = _context.Products.Include(c => c.ProductTypes).Where(c => c.Id == id).FirstOrDefault();

            if(product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        [HttpPost]
        [ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmAsync(int? id)
        {
            if(id == null)
            {
                return NotFound();
            }
            var product = _context.Products.FirstOrDefault(c => c.Id == id);
            if(product == null)
            {
                return NotFound();
            }
            _context.Remove(product);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }

}
