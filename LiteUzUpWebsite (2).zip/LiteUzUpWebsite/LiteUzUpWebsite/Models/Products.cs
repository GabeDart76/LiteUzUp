﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LiteUzUpWebsite.Models
{
    public class Products
    {
        [Required]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public decimal Price { get; set; }
        [Required]
        public string Colour { get; set; }
        public string Image { get; set; }
        [Required]
        public bool IsAvalible { get; set; }
        [Required]
        public int ProductTypeId { get; set; }
        [ForeignKey("ProductTypeId")]
        //[Required]
        public ProductTypes ProductTypes { get; set; }

        
    }
}
